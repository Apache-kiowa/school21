#include <stdio.h>
// Функция для считывания массива из stdin
void readArray(int *arr, int size) {
    for (int i = 0; i < size; ++i) {
        if (scanf("%d", &arr[i]) != 1) {
            printf("n/a\n");
            return;
        }
    }
}

// Функция для сортировки массива по возрастанию (используется сортировка пузырьком)
void bubbleSort(int *arr, int size) {
    for (int i = 0; i < size - 1; ++i) {
        for (int j = 0; j < size - i - 1; ++j) {
            if (arr[j] > arr[j + 1]) {
                // Обмен элементов
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

// Функция для вывода массива
void printArray(int *arr, int size) {
    for (int i = 0; i < size; ++i) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    // Размер массива
    const int SIZE = 10;
    int arr[SIZE];

    // Считываем массив из stdin
    readArray(arr, SIZE);

    // Если массив успешно считан, то продолжаем сортировку и вывод
    if (arr[0] != '\0') {
        // Сортируем массив
        bubbleSort(arr, SIZE);

        // Выводим отсортированный массив
        printArray(arr, SIZE);
    }

    return 0;
}
