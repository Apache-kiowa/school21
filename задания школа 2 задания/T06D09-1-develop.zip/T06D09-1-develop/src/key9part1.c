#include <stdio.h>

#define MAX_SIZE 10

void input(int *buffer, int *length);
void output(int *buffer, int length);
int sum_numbers(int *buffer, int length);
int find_numbers(int *buffer, int length, int number, int *numbers);

int main() {
    int buffer[MAX_SIZE];
    int length;

    input(buffer, &length);

    int sum = sum_numbers(buffer, length);

    if (sum == -1) {
        printf("n/a\n");
        return 0;
    }

    int new_buffer[MAX_SIZE];
    int new_length = find_numbers(buffer, length, sum, new_buffer);

    output(new_buffer, new_length);

    return 0;
}

void input(int *buffer, int *length) {
    scanf("%d", length);

    if (*length <= 0 || *length > MAX_SIZE) {
        *length = 0;
        return;
    }

    for (int i = 0; i < *length; i++) {
        scanf("%d", &buffer[i]);
    }
}

void output(int *buffer, int length) {
    for (int i = 0; i < length; i++) {
        printf("%d ", buffer[i]);
    }
    printf("\n");
}

int sum_numbers(int *buffer, int length) {
    int sum = 0;

    for (int i = 0; i < length; i++) {
        if (buffer[i] % 2 == 0) {
            sum += buffer[i];
        }
    }

    if (sum == 0) {
        return -1;  // Indicate no even numbers found
    }

    return sum;
}

int find_numbers(int *buffer, int length, int number, int *numbers) {
    int new_length = 0;

    for (int i = 0; i < length; i++) {
        if (buffer[i] % number == 0) {
            numbers[new_length++] = buffer[i];
        }
    }

    return new_length;
}
