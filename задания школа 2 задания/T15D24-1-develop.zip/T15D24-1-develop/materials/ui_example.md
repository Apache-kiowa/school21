      Please choose one operation:
        1. SELECT
        2. INSERT
        3. UPDATE
        4. DELETE
        5. Get all active additional modules (last module status is 1)
        6. Delete modules by ids
        7. Set protected mode for module by id
        8. Move module by id to specified memory level and cell
        9. Set protection flag of the specified memory level
    > 1
      Please choose a table:
        1. Modules
        2. Levels
        3. Status events
    > 1
    > Insert the number of records or leave empty to output all of them: 2

      0 Main module 4 3 0
      1 Text module 2 3 0

      Please choose one operation:
        1. SELECT
        2. INSERT
        3. UPDATE
        4. DELETE
        5. Get all active additional modules (last module status is 1)
        6. Delete modules by ids
        7. Set protected mode for module by id
        8. Move module by id to specified memory level and cell
        9. Set protection flag of the specified memory level
    > 6
    > Please input the ids of the deleting modules: 1 2 30

      Modules 1, 2, 30 marked as deleted

      ...
