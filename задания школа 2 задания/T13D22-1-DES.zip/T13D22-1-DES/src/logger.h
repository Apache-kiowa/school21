#ifndef LOGGER_H
#define LOGGER_H

#include <stdio.h>
#include <time.h>

// Определение перечисления для уровней логирования
typedef enum { DEBUG, INFO, WARNING, ERROR } LogLevel;

// Функция для инициализации логгера
void log_init(const char *log_file);

// Функция для записи сообщения в лог
void logcat(LogLevel level, const char *message);

// Функция для закрытия лога
void log_close();

#endif /* LOGGER_H */
