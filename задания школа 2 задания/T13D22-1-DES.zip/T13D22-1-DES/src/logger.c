#include "logger.h"

// Переменная для хранения указателя на файл лога
static FILE *log_file_ptr = NULL;

// Функция для инициализации логгера
void log_init(const char *log_file) {
  log_file_ptr = fopen(log_file, "a");
  if (log_file_ptr == NULL) {
    perror("Ошибка при открытии файла лога");
  }
}

// Функция для записи сообщения в лог
void logcat(LogLevel level, const char *message) {
  if (log_file_ptr != NULL) {
    // Получение текущего времени
    time_t current_time = time(NULL);
    char *time_str = ctime(&current_time);
    time_str[strlen(time_str) - 1] =
        '\0'; // Удаление символа новой строки в конце временной метки

    // Получение строки для уровня логирования
    char *level_str;
    switch (level) {
    case DEBUG:
      level_str = "DEBUG";
      break;
    case INFO:
      level_str = "INFO";
      break;
    case WARNING:
      level_str = "WARNING";
      break;
    case ERROR:
      level_str = "ERROR";
      break;
    default:
      level_str = "UNKNOWN";
      break;
    }

    // Запись сообщения в файл лога
    fprintf(log_file_ptr, "[%s] %s: %s\n", time_str, level_str, message);
    fflush(log_file_ptr); // Принудительная сброс буфера
  }
}

// Функция для закрытия лога
void log_close() {
  if (log_file_ptr != NULL) {
    fclose(log_file_ptr);
  }
}
