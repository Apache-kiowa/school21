#include <stdio.h>
#include <math.h>

float important_function(float x) {
    float y;


    if (x <= 0) {
        return NAN;
    }


    y = 7e-3 * pow(x, 4) + ((22.8 * cbrt(x) - 1e3) * x + 3) / (x * x / 2) - x * pow(10 + x, 2/x) - 1.01;

    return y;
}

int main() {
    float x;

    printf("Введите число x с плавающей точкой: ");
    if (scanf("%f", &x) != 1) {
        printf("n/a\n");
        return 1;
    }


    float result = important_function(x);
    if (isnan(result)) {
        printf("n/a\n");
    } else {
        printf("Результат: %.1f\n", result);
    }

    return 0;
}
