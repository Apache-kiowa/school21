#include <stdio.h>

int main() {
    float x, y;

    
    printf("Введите координату x: ");
    if (scanf("%f", &x) != 1) {
        printf("n/a\n");
        return 1;  
    }

    printf("Введите координату y: ");
    if (scanf("%f", &y) != 1) {
        printf("n/a\n");
        return 1; 
    }


    if (x * x + y * y <= 25.0) {
        printf("GOTCHA\n");
    } else {
        printf("MISS\n");
    }

    return 0;
}