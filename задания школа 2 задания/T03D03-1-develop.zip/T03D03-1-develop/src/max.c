#include <stdio.h>

int max(int a, int b) {
    return a > b ? a : b;
}

int main() {
    int num1, num2;

    if (scanf("%d %d", &num1, &num2) != 2) {
        printf("n/a\n");
        return 1;
    }
    
    int maximum = max(num1, num2);
    printf("Наибольшее число: %d\n", maximum);

    return 0;
}