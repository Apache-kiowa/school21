#include <stdio.h>


int sum(int a, int b);
int difference(int a, int b);
int product(int a, int b);
int quotient(int a, int b);

int main() {
    int num1, num2;

    if (scanf("%d", &num1) != 1 || getchar() != ' ' || scanf("%d", &num2) != 1 || getchar() != '\n') {
        printf("n/a");
        return 1;
    }

    printf("%d %d %d ", sum(num1, num2), difference(num1, num2), product(num1, num2));

    if (num2 != 0) {
        printf("%d", quotient(num1, num2));
    } else {
        printf("n/a");
    }

    return 0;
}

int sum(int a, int b) {
    return a + b;
}

int difference(int a, int b) {
    return a - b;
}

int product(int a, int b) {
    return a * b;
}

int quotient(int a, int b) {
    return a / b;
}
