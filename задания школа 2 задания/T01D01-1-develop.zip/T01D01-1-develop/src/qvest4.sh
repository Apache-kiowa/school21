kill #id
ps
bash ai_door_management_module.sh
touch qvest4.sh

