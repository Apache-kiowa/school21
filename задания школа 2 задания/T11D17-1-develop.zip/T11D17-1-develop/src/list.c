#include <stdio.h>
#include <stdlib.h>

struct door {
    int id;
};

struct node {
    struct door* door;
    struct node* next;
};

struct node* init(struct door* door) {
    struct node* head = (struct node*)malloc(sizeof(struct node));
    if (head == NULL) {
        printf("Ошибка при выделении памяти\n");
        exit(EXIT_FAILURE);
    }
    head->door = door;
    head->next = NULL;
    return head;
}

struct node* add_door(struct node* elem, struct door* door) {
    struct node* new_node = (struct node*)malloc(sizeof(struct node));
    if (new_node == NULL) {
        printf("Ошибка при выделении памяти\n");
        exit(EXIT_FAILURE);
    }
    new_node->door = door;
    new_node->next = elem->next;
    elem->next = new_node;
    return new_node;
}

struct node* find_door(int door_id, struct node* root) {
    struct node* current = root;
    while (current != NULL) {
        if (current->door->id == door_id) {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

struct node* remove_door(struct node* elem, struct node* root) {
    struct node* current = root;
    struct node* prev = NULL;
    while (current != NULL) {
        if (current == elem) {
            if (prev == NULL) {
                root = current->next;
            } else {
                prev->next = current->next;
            }
            free(current);
            return root;
        }
        prev = current;
        current = current->next;
    }
    return root;
}

void destroy(struct node* root) {
    struct node* current = root;
    struct node* next;
    while (current != NULL) {
        next = current->next;
        free(current->door);
        free(current);
        current = next;
    }
}

int main() {
    struct door* door1 = (struct door*)malloc(sizeof(struct door));
    door1->id = 1;

    struct door* door2 = (struct door*)malloc(sizeof(struct door));
    door2->id = 2;

    struct door* door3 = (struct door*)malloc(sizeof(struct door));
    door3->id = 3;

    struct node* root = init(door1);
    add_door(root, door2);
    add_door(root->next, door3);

    struct node* found_door = find_door(2, root);
    if (found_door != NULL) {
        printf("SUCCESS Дверь с id 2 найдена\n");
    } else {
        printf("FAIL Дверь с id 2 не найдена\n");
    }

    root = remove_door(root->next, root);

    destroy(root);

    return 0;
}
