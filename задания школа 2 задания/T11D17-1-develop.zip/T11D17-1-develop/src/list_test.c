#include "list.h"

#include <assert.h>
#include <stdio.h>

#define SUCCESS 0
#define FAIL 1

int test_add_remove() {
    struct door door1 = {1, 0};
    struct door door2 = {2, 0};
    struct door door3 = {3, 0};

    struct node* root = init(&door1);
    assert(root != NULL);

    struct node* elem = add_door(root, &door2);
    assert(elem != NULL);

    elem = add_door(elem, &door3);
    assert(elem != NULL);

    struct node* found = find_door(2, root);
    assert(found != NULL && found->data.id == 2);

    root = remove_door(elem, root);
    assert(root != NULL);

    found = find_door(2, root);
    assert(found == NULL);

    destroy(root);

    return SUCCESS;
}
