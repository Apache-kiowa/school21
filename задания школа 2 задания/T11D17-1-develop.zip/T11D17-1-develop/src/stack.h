#ifndef STACK_H
#define STACK_H

typedef struct StackNode {
    int data;
    struct StackNode* next;
} StackNode;

typedef struct {
    StackNode* top;
} Stack;

typedef enum { SUCCESS, FAIL } Status;

void init(Stack* stack);
Status push(Stack* stack, int data);
Status pop(Stack* stack, int* data);
void destroy(Stack* stack);

#endif
