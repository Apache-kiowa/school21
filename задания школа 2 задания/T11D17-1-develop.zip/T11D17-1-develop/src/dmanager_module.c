#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "door_struct.h"

#define DOORS_COUNT 15
#define MAX_ID_SEED 10000

void initialize_doors(struct door* doors);

int compare_doors(const void* a, const void* b);

int main() {
    struct door doors[DOORS_COUNT];

    initialize_doors(doors);

    qsort(doors, DOORS_COUNT, sizeof(struct door), compare_doors);

    printf("Отсортированный массив дверей:\n");
    for (int i = 0; i < DOORS_COUNT; i++) {
        doors[i].status = 0;
        printf("%d, %d\n", doors[i].id, doors[i].status);
    }

    return 0;
}

int compare_doors(const void* a, const void* b) {
    struct door* door_a = (struct door*)a;
    struct door* door_b = (struct door*)b;

    return (door_a->id - door_b->id);
}

void initialize_doors(struct door* doors) {
    srand(time(0));

    int seed = rand() % MAX_ID_SEED;
    for (int i = 0; i < DOORS_COUNT; i++) {
        doors[i].id = (i + seed) % DOORS_COUNT;
        doors[i].status = rand() % 2;
    }
}
