#include "stack.h"

#include <stdlib.h>

void init(Stack* stack) { stack->top = NULL; }

Status push(Stack* stack, int data) {
    StackNode* newNode = (StackNode*)malloc(sizeof(StackNode));
    if (newNode == NULL) {
        return FAIL;
    }
    newNode->data = data;
    newNode->next = stack->top;
    stack->top = newNode;
    return SUCCESS;
}

Status pop(Stack* stack, int* data) {
    if (stack->top == NULL) {
        return FAIL;
    }
    *data = stack->top->data;
    StackNode* temp = stack->top;
    stack->top = stack->top->next;
    free(temp);
    return SUCCESS;
}

void destroy(Stack* stack) {
    StackNode* current = stack->top;
    while (current != NULL) {
        StackNode* temp = current;
        current = current->next;
        free(temp);
    }
}
