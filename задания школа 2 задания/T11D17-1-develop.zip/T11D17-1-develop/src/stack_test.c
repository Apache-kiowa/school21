#include "stack.h"

#include <stdio.h>

int main() {
    Stack stack;
    int data;

    init(&stack);

    push(&stack, 10);
    pop(&stack, &data);
    if (data == 10) {
        printf("SUCCESS\n");
        return SUCCESS;
    } else {
        printf("FAIL\n");
        return FAIL;
    }
}
