#include <stdio.h>
#include <stdlib.h>

double det(double **matrix, int n, int m);
void input(double ***matrix, int *n, int *m);
void output(double det);

int main() {
    int n, m;
    double **matrix;

    input(&matrix, &n, &m);
    double determinant = det(matrix, n, m);
    output(determinant);

    for (int i = 0; i < n; i++) {
        free(matrix[i]);
    }
    free(matrix);

    return 0;
}

double det(double **matrix, int n, int m) {
    if (n != m) {
        return 0.0;
    }

    if (n == 1) {
        return matrix[0][0];
    }

    double result = 0.0;
    int sign = 1;
    int i, j, k;

    for (i = 0; i < n; i++) {
        double **submatrix = (double **)malloc((n - 1) * sizeof(double *));
        for (j = 0; j < n - 1; j++) {
            submatrix[j] = (double *)malloc((n - 1) * sizeof(double));
        }

        for (j = 1; j < n; j++) {
            for (k = 0; k < n; k++) {
                if (k < i) {
                    submatrix[j - 1][k] = matrix[j][k];
                } else if (k > i) {
                    submatrix[j - 1][k - 1] = matrix[j][k];
                }
            }
        }

        result += sign * matrix[0][i] * det(submatrix, n - 1, m - 1);
        for (j = 0; j < n - 1; j++) {
            free(submatrix[j]);
        }
        free(submatrix);

        sign = -sign;
    }

    return result;
}

void input(double ***matrix, int *n, int *m) {
    scanf("%d %d", n, m);

    *matrix = (double **)malloc(*n * sizeof(double *));
    for (int i = 0; i < *n; i++) {
        (*matrix)[i] = (double *)malloc(*m * sizeof(double));
    }

    for (int i = 0; i < *n; i++) {
        for (int j = 0; j < *m; j++) {
            scanf("%lf", &(*matrix)[i][j]);
        }
    }
}

void output(double det) { printf("%.6lf", det); }
