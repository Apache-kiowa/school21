#ifndef S21_STRING_H
#define S21_STRING_H

#include <stddef.h>

size_t s21_strlen(const char *str);

#endif  // S21_STRING_H
