#include "s21_string.h"

#include <stdio.h>
#include <stdlib.h>

// Функция для сравнения строк
int compare_strings(const char *str1, const char *str2) {
    while (*str1 && *str2) {
        if (*str1 != *str2) return 0;
        str1++;
        str2++;
    }
    if (*str1 || *str2) return 0;
    return 1;
}

// Функция для тестирования s21_strlen
void s21_strlen_test() {
    printf("Testing s21_strlen:\n");

    // Тест 1: Нормальное значение
    const char *str1 = "Hello, world!";
    size_t expected_len1 = 13;
    size_t len1 = s21_strlen(str1);
    printf("Input: \"%s\", Expected: %zu, Result: %s\n", str1, expected_len1,
           len1 == expected_len1 ? "SUCCESS" : "FAIL");

    // Тест 2: Пустая строка
    const char *str2 = "";
    size_t expected_len2 = 0;
    size_t len2 = s21_strlen(str2);
    printf("Input: \"%s\", Expected: %zu, Result: %s\n", str2, expected_len2,
           len2 == expected_len2 ? "SUCCESS" : "FAIL");

    // Тест 3: Строка с пробелами
    const char *str3 = "   ";
    size_t expected_len3 = 3;
    size_t len3 = s21_strlen(str3);
    printf("Input: \"%s\", Expected: %zu, Result: %s\n", str3, expected_len3,
           len3 == expected_len3 ? "SUCCESS" : "FAIL");

    // Добавьте дополнительные тесты здесь

    printf("s21_strlen tests completed.\n");
}

int main() {
    s21_strlen_test();
    return 0;
}
