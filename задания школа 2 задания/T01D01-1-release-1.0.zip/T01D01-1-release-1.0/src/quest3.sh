mv door_management_fi door_managment_files

chmod +x ai_door_control.sh 

cd door_management_files

mkdir door_configuration
mkdir door_logs
mkdir door_map

mv *.conf door_configuration
mv *.log door_logs
mv *.1 door_map

bash ai_door_managment_module.sh
