#include "data_io.h"

#include <stdio.h>

void input(double *data, int n) {
    printf("Enter %d numbers:\n", n);
    for (int i = 0; i < n; i++) {
        printf("Enter number %d: ", i + 1);
        scanf("%lf", &data[i]);  // Считываем числа с клавиатуры
    }
}

void output(double *data, int n) {
    printf("Outputting %d numbers:\n", n);
    for (int i = 0; i < n; i++) {
        printf("%.2lf ", data[i]);  // Выводим числа с двумя знаками после запятой
    }
    printf("\n");
}
