#ifndef DATA_IO_MACRO_H
#define DATA_IO_MACRO_H

#include <stdio.h>

void input(double *data, int n);
void output(double *data, int n);

double max(double *data, int n);
double min(double *data, int n);
double mean(double *data, int n);
double variance(double *data, int n);

double sort(double *data, int n);

// Макрос для вывода элементов массива
#define PRINT_ARRAY(arr, len)               \
    do {                                    \
        printf("[");                        \
        for (int i = 0; i < len; i++) {     \
            printf("%d", arr[i]);           \
            if (i != len - 1) printf(", "); \
        }                                   \
        printf("]\n");                      \
    } while (0)

// Макрос для считывания элементов массива
#define READ_ARRAY(arr, len)                 \
    do {                                     \
        printf("Enter %d elements:\n", len); \
        for (int i = 0; i < len; i++) {      \
            scanf("%d", &arr[i]);            \
        }                                    \
    } while (0)

#endif /* DATA_IO_MACRO_H */
