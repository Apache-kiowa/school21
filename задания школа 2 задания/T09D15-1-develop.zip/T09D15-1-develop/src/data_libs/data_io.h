#ifndef DATA_IO_H
#define DATA_IO_H

void input(double *data, int n);
void output(double *data, int n);

#endif
