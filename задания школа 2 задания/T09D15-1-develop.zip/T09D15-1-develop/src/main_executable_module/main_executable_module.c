#include <stdio.h>
#include <stdlib.h>

// Включаем заголовочный файл в зависимости от макроса USE_DATA_IO_MACRO
#ifdef USE_DATA_IO_STANDARD
#include "../data_libs/data_io_macro.h"
#else
#include "../data_libs/data_io.h"
#endif

#include "../data_libs/data_stat.h"
#include "../data_module/data_process.h"
#include "../yet_another_decision_module/decision.h"

#if defined(USE_DATA_IO_MACRO)
#include "../data_libs/data_io_macro.h"
#else
#include "../data_libs/data_io.h"

#endif

int main() {
    double *data;
    int n;

    printf("Enter the number of data points: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Error: Number of data points must be positive.\n");
        return 1;
    }

    data = (double *)malloc(n * sizeof(double));
    if (data == NULL) {
        printf("Error: Memory allocation failed.\n");
        return 1;
    }

    printf("LOAD DATA...\n");
    input(data, n);

    printf("RAW DATA:\n\t");
    output(data, n);

    printf("\nNORMALIZED DATA:\n\t");
    normalization(data, n);
    output(data, n);

    printf("\nSORTED NORMALIZED DATA:\n\t");
    sort(data, n);
    output(data, n);

    printf("\nFINAL DECISION:\n\t");
    make_decision(data, n);

    free(data);

    return 0;
}
