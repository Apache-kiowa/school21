#include <stdio.h>
#include <stdlib.h>

#include "../data_libs/data_io.h"
#include "../data_libs/data_stat.h"
#include "data_process.h"

int main() {
    double *data;  // Объявление указателя на массив данных
    int n;         // Объявление переменной для количества элементов

    // Запрашиваем у пользователя количество элементов
    scanf("%d", &n);

    // Выделяем память для массива данных
    data = (double *)malloc(n * sizeof(double));
    if (data == NULL) {
        printf("Memory allocation failed\n");
        return 1;  // Возвращаем 1, чтобы показать, что произошла ошибка
    }

    // Запрашиваем у пользователя ввод данных
    for (int i = 0; i < n; i++) {
        scanf("%lf", &data[i]);
    }

    // Обрабатываем данные и выводим результат
    if (normalization(data, n))
        output(data, n);
    else
        printf("ERROR");

    // Освобождаем память, выделенную для массива data
    free(data);

    return 0;
}
