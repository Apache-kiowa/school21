cd ai_help/
bash keygen.sh
cd key
ls -a
rm *file*
cd ..
bash keygen.sh
bash unifier.sh

