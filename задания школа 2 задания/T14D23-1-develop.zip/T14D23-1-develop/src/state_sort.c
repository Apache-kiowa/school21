#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

struct Record {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
};

void print_file_content();
void sort_file_content();
void add_record_and_sort();
void exit_program();
void print_record(const struct Record *record);
int get_records_count_in_file(FILE *pfile);

char file_path[100];

int main() {
    int choice;
    do {
        scanf("%99s", file_path);
        scanf("%d", &choice);

        switch (choice) {
            case 0:
                print_file_content();
                break;
            case 1:
                sort_file_content();
                break;
            case 2:
                add_record_and_sort();
                break;
            case 3:
                exit_program();
                break;
            default:
                printf("n/a\n");
                break;
        }
    } while (choice != 3);

    return 0;
}

void print_file_content() {
    FILE *file = fopen(file_path, "rb");
    if (!file) {
        perror("n/a");
        return;
    }

    struct Record record;

    while (fread(&record, sizeof(struct Record), 1, file) == 1) {
        print_record(&record);
    }

    fclose(file);
}

void sort_file_content() {
    FILE *file = fopen(file_path, "rb+");
    if (!file) {
        perror("n/a");
        return;
    }

    int n = get_records_count_in_file(file);

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            struct Record record1, record2;
            fseek(file, j * sizeof(struct Record), SEEK_SET);
            fread(&record1, sizeof(struct Record), 1, file);
            fread(&record2, sizeof(struct Record), 1, file);
            if (record1.year > record2.year ||
                (record1.year == record2.year && record1.month > record2.month) ||
                (record1.year == record2.year && record1.month == record2.month &&
                 record1.day > record2.day) ||
                (record1.year == record2.year && record1.month == record2.month &&
                 record1.day == record2.day && record1.hour > record2.hour) ||
                (record1.year == record2.year && record1.month == record2.month &&
                 record1.day == record2.day && record1.hour == record2.hour &&
                 record1.minute > record2.minute) ||
                (record1.year == record2.year && record1.month == record2.month &&
                 record1.day == record2.day && record1.hour == record2.hour &&
                 record1.minute == record2.minute && record1.second > record2.second)) {
                fseek(file, j * sizeof(struct Record), SEEK_SET);
                fwrite(&record2, sizeof(struct Record), 1, file);
                fseek(file, (j + 1) * sizeof(struct Record), SEEK_SET);
                fwrite(&record1, sizeof(struct Record), 1, file);
            }
        }
    }

    rewind(file);
    print_file_content();

    fclose(file);
}

void add_record_and_sort() {
    FILE *file = fopen(file_path, "ab+");
    if (!file) {
        perror("n/a");
        return;
    }

    struct Record new_record;

    scanf("%d %d %d %d %d %d %d %d", &new_record.year, &new_record.month, &new_record.day, &new_record.hour,
          &new_record.minute, &new_record.second, &new_record.status, &new_record.code);

    fwrite(&new_record, sizeof(struct Record), 1, file);
    fflush(file);

    sort_file_content();

    fclose(file);
}

void exit_program() { exit(0); }

void print_record(const struct Record *record) {
    printf("%d %d %d %d %d %d %d %d\n", record->year, record->month, record->day, record->hour,
           record->minute, record->second, record->status, record->code);
}

int get_records_count_in_file(FILE *pfile) {
    fseek(pfile, 0, SEEK_END);
    int file_size = ftell(pfile);
    int records_count = file_size / sizeof(struct Record);

    return records_count;
}
