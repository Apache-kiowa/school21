#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

struct Record {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
};

int main() {
    char file_path[256];
    fgets(file_path, sizeof(file_path), stdin);
    if (file_path[strlen(file_path) - 1] == '\n') {
        file_path[strlen(file_path) - 1] = '\0';
    }

    FILE *file = fopen(file_path, "rb+");
    if (!file) {
        perror("n/a");
        return 1;
    }

    char date_range[256];
    fgets(date_range, sizeof(date_range), stdin);
    if (date_range[strlen(date_range) - 1] == '\n') {
        date_range[strlen(date_range) - 1] = '\0';
    }

    int start_day, start_month, start_year;
    int end_day, end_month, end_year;
    sscanf(date_range, "%d.%d.%d %d.%d.%d", &start_day, &start_month, &start_year, &end_day, &end_month,
           &end_year);

    if (start_year > end_year ||
        (start_year == end_year &&
         (start_month > end_month || (start_month == end_month && (start_day > end_day))))) {
        printf("n/a\n");
        fclose(file);
        return 1;
    }

    fseek(file, 0, SEEK_END);
    long record_size = ftell(file) / sizeof(struct Record);
    if (record_size == 0) {
        printf("n/a\n");
        fclose(file);
        return 0;
    }

    struct Record record;
    long write_index = 0;
    for (long i = 0; i < record_size; i++) {
        fseek(file, i * sizeof(struct Record), SEEK_SET);
        fread(&record, sizeof(struct Record), 1, file);

        if ((record.year > start_year || (record.year == start_year && record.month > start_month) ||
             (record.year == start_year && record.month == start_month && record.day >= start_day)) &&
            (record.year < end_year || (record.year == end_year && record.month < end_month) ||
             (record.year == end_year && record.month == end_month && record.day <= end_day))) {
        } else {
            fseek(file, write_index * sizeof(struct Record), SEEK_SET);
            fwrite(&record, sizeof(struct Record), 1, file);
            write_index++;
        }
    }

    ftruncate(fileno(file), write_index * sizeof(struct Record));

    rewind(file);

    while (fread(&record, sizeof(struct Record), 1, file) == 1) {
        printf("%d %d %d %d %d %d %d %d\n", record.year, record.month, record.day, record.hour, record.minute,
               record.second, record.status, record.code);
    }

    fclose(file);

    return 0;
}
