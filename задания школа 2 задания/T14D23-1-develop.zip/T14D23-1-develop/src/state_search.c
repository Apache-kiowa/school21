#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Record {
    int year;
    int month;
    int day;
    int code;
};

int main() {
    char file_path[100];

    scanf("%99s", file_path);

    FILE *file = fopen(file_path, "rb");
    if (!file) {
        perror("n/a");
        return 1;
    }

    char search_date[11];

    scanf("%10s", search_date);

    struct Record record;
    while (fread(&record, sizeof(struct Record), 1, file) == 1) {
        int year, month, day;
        sscanf(search_date, "%d.%d.%d", &day, &month, &year);

        if (record.year == year && record.month == month && record.day == day) {
            printf("%d\n", record.code);
            fclose(file);
            return 0;
        }
    }

    printf("n/a\n");
    fclose(file);
    return 0;
}
