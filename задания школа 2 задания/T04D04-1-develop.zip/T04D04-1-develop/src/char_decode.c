#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_INPUT_LENGTH 20  // Максимальная длина входной строки

// Функция кодирования символа в шестнадцатеричное представление
void encode(char symbol) { printf("%02X ", symbol); }

int main() {
    int mode;

    printf("Select mode:\n");
    printf("0: Encoding\n");
    printf("1: Decoding\n");
    scanf("%d", &mode);
    fflush(stdin);

    if (mode == 0) {
        char input[MAX_INPUT_LENGTH];
        printf("Enter characters to encode (press Enter to finish):\n");
        fgets(input, sizeof(input), stdin);

        // Проверяем, есть ли в строке пробелы
        int has_space = 0;
        for (int i = 0; input[i] != '\0'; i++) {
            if (input[i] == ' ') {
                has_space = 1;
                break;
            }
        }

        if (has_space) {
            // Если есть пробелы, кодируем символы
            for (int i = 0; input[i] != '\0'; i++) {
                encode(input[i]);
            }
            printf("\n");
        } else {
            // Если нет пробелов, выводим "n/a"
            printf("n/a\n");
        }
    } else if (mode == 1) {
        // Добавьте здесь ваш код для декодирования
    } else {
        printf("Invalid mode! Use 0 for encoding or 1 for decoding.\n");
        return 1;
    }

    return 0;
}
