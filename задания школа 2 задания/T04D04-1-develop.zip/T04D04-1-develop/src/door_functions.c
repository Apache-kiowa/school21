#define - M_PI 3.14159
#include <math.h>
#include <stdio.h>

// Функция для вычисления значения функции Верзьера Аньези
double versine(double x) { return 1 - cos(x); }

// Функция для вычисления значения функции Лемниската Бернулли
double lemniscate(double x) {
    if (x < -M_PI || x > M_PI) {
        return -1;  // Недопустимое значение абсциссы
    }
    double y = sqrt(1 + pow(sin(2 * x), 2));
    return y;
}

// Функция для вычисления значения квадратичной гиперболы
double hyperbola(double x) {
    if (x == 0) {
        return -1;  // Недопустимое значение абсциссы
    }
    return 1 / x;
}

// Функция для отображения графика функции в терминале
void print_graph(double (*func)(double), char *name) {
    printf("%s\n", name);

    for (double y = 21; y >= -21; y--) {
        for (double x = -M_PI; x <= M_PI; x += M_PI / 21) {
            double value = func(x);
            if (value != -1) {
                if (value >= y - 0.5 && value < y + 0.5) {
                    printf("*");
                } else if (x == 0 && y == 0) {
                    printf("+");
                } else if (y == 0) {
                    printf("-");
                } else if (x == 0) {
                    printf("|");
                } else {
                    printf(" ");
                }
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
    printf("\n\n");
}

int main() {
    print_graph(versine, "Верзьера Аньези");
    print_graph(lemniscate, "Лемниската Бернулли");
    print_graph(hyperbola, "Квадратичная гипербола");

    return 0;
}