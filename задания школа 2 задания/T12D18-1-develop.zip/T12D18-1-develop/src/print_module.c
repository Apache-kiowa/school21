#include "print_module.h"

#include <stdio.h>
#include <time.h>

void print_log(char (*print)(char), char* message) {
    time_t rawtime;
    struct tm* timeinfo;
    char buffer[9];  // для времени формата ЧЧ:ММ:СС + символ конца строки

    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(buffer, sizeof(buffer), "%H:%M:%S", timeinfo);

    // Выводим префикс, текущее время и сообщение
    print('[');
    for (int i = 0; i < 9; i++) {
        if (buffer[i] == '\0') break;
        print(buffer[i]);
    }
    print(']');
    print(' ');

    while (*message != '\0') {
        print(*message++);
    }
}

// Пример реализации print_char
char print_char(char ch) { return putchar(ch); }
