#include <math.h>
#include <stdio.h>
#define NMAX 10

int input(int *a, int *n);
void output(int *a, int n);
int max(int *a, int n);
int min(int *a, int n);
double mean(int *a, int n);
double variance(int *a, int n);

void output_result(int max_v, int min_v, double mean_v, double variance_v);

int main() {
  int n, data[NMAX];
  n = input(data, &n);
  if (n > 0) {
    output(data, n);
    output_result(max(data, n), min(data, n), mean(data, n), variance(data, n));
  } else {
    printf("n/a\n");
  }

  return 0;
}

int input(int *a, int *n) {
  printf("Enter the number of elements (up to %d): ", NMAX);
  scanf("%d", n);
  printf("Enter %d integers:\n", *n);
  for (int i = 0; i < *n; ++i) {
    scanf("%d", &a[i]);
  }
  return *n;
}

void output(int *a, int n) {
  printf("Array elements: ");
  for (int i = 0; i < n; ++i) {
    printf("%d ", a[i]);
  }
  printf("\n");
}

int max(int *a, int n) {
  int max_val = a[0];
  for (int i = 1; i < n; ++i) {
    if (a[i] > max_val) {
      max_val = a[i];
    }
  }
  return max_val;
}

int min(int *a, int n) {
  int min_val = a[0];
  for (int i = 1; i < n; ++i) {
    if (a[i] < min_val) {
      min_val = a[i];
    }
  }
  return min_val;
}

double mean(int *a, int n) {
  double sum = 0.0;
  for (int i = 0; i < n; ++i) {
    sum += a[i];
  }
  return sum / n;
}

double variance(int *a, int n) {
  double mean_val = mean(a, n);
  double sum_squared_diff = 0.0;
  for (int i = 0; i < n; ++i) {
    sum_squared_diff += (a[i] - mean_val) * (a[i] - mean_val);
  }
  return sum_squared_diff / n;
}

void output_result(int max_v, int min_v, double mean_v, double variance_v) {
  printf("%d %d %.6lf %.6lf", max_v, min_v, mean_v, variance_v);
}
