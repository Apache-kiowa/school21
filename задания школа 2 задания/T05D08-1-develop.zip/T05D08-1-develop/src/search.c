#include <math.h>
#include <stdio.h>

#define MAX_SIZE 30

int input(int *a);
int is_even(int num);
int find_desired_value(int *a, int size, double mean, double variance);

int main() {
  int data[MAX_SIZE];
  int size = input(data);

  if (size > 0) {
    double sum = 0.0;
    for (int i = 0; i < size; ++i) {
      sum += data[i];
    }
    double mean = sum / size;

    double sum_squared_diff = 0.0;
    for (int i = 0; i < size; ++i) {
      sum_squared_diff += (data[i] - mean) * (data[i] - mean);
    }
    double variance = sum_squared_diff / size;

    int result = find_desired_value(data, size, mean, variance);
    if (result != 0) {
      printf("%d\n", result);
    } else {
      printf("0\n");
    }
  } else {
    printf("n/a\n");
  }

  return 0;
}

int input(int *a) {
  printf("Enter the number of elements (up to %d): ", MAX_SIZE);
  int size;
  scanf("%d", &size);

  printf("Enter %d integers:\n", size);
  for (int i = 0; i < size; ++i) {
    scanf("%d", &a[i]);
  }
  return size;
}

int is_even(int num) { return num % 2 == 0; }

int find_desired_value(int *a, int size, double mean, double variance) {
  for (int i = 0; i < size; ++i) {
    if (is_even(a[i]) && a[i] >= mean && a[i] <= mean + 3 * sqrt(variance) &&
        a[i] != 0) {
      return a[i];
    }
  }
  return 0;
}
