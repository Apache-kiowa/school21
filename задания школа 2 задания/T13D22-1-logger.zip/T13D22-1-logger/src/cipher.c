#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "logger.h"

#define MAX_FILENAME_LENGTH 256
#define SRC_FOLDER "../src/"

void clear_input_buffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF)
        ;
}

void read_and_print_file(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("n/a\n");
        return;
    }

    int c;
    int isEmpty = 1;
    while ((c = fgetc(file)) != EOF) {
        isEmpty = 0;
        putchar(c);
    }
    fclose(file);

    if (isEmpty) {
        printf("n/a\n");
    }
}

void append_to_file(const char *filename, const char *text) {
    FILE *file = fopen(filename, "a");
    if (file == NULL) {
        printf("n/a\n");
        return;
    }

    fprintf(file, "%s\n", text);
    fclose(file);
}

void caesar_cipher(char *text, int shift) {
    for (int i = 0; text[i] != '\0'; ++i) {
        if (text[i] >= 'a' && text[i] <= 'z') {
            text[i] = 'a' + (text[i] - 'a' + shift) % 26;
        } else if (text[i] >= 'A' && text[i] <= 'Z') {
            text[i] = 'A' + (text[i] - 'A' + shift) % 26;
        }
    }
}

void clear_header_files(const char *directory) {
    DIR *dir;
    struct dirent *entry;

    if ((dir = opendir(directory)) != NULL) {
        while ((entry = readdir(dir)) != NULL) {
            char *filename = entry->d_name;
            size_t len = strlen(filename);
            char filepath[MAX_FILENAME_LENGTH];
            snprintf(filepath, MAX_FILENAME_LENGTH, "%s/%s", directory, filename);

            if (len > 2 && strcmp(filename + len - 2, ".h") == 0) {
                FILE *file = fopen(filepath, "wb");
                if (file != NULL) {
                    fclose(file);
                }
            }
        }
        closedir(dir);
    }
}

void caesar_cipher_c_files(const char *directory, int shift) {
    DIR *dir;
    struct dirent *entry;

    if ((dir = opendir(directory)) != NULL) {
        while ((entry = readdir(dir)) != NULL) {
            char *filename = entry->d_name;
            size_t len = strlen(filename);
            if (len > 2 && strcmp(filename + len - 2, ".c") == 0) {
                char filepath[MAX_FILENAME_LENGTH];
                snprintf(filepath, MAX_FILENAME_LENGTH, "%s/%s", directory, filename);
                FILE *file = fopen(filepath, "r+");
                if (file != NULL) {
                    // Определение размера файла
                    fseek(file, 0, SEEK_END);
                    size_t fileSize = ftell(file);
                    rewind(file);

                    // Динамическое выделение памяти под содержимое файла
                    char *fileContent = (char *)malloc(fileSize + 1);
                    if (fileContent != NULL) {
                        // Чтение содержимого файла в память
                        size_t bytesRead = fread(fileContent, 1, fileSize, file);
                        fileContent[bytesRead] = '\0';  // Добавление символа конца строки

                        // Зашифровка содержимого файла
                        caesar_cipher(fileContent, shift);

                        // Перезапись зашифрованного содержимого в файл
                        rewind(file);
                        fwrite(fileContent, 1, bytesRead, file);

                        // Освобождение памяти, выделенной под содержимое файла
                        free(fileContent);
                    }
                    fclose(file);
                }
            }
        }
        closedir(dir);
    }
}

#include "logger.h"  // Включаем заголовочный файл логгера

int main() {
    // Инициализация логгера
    log_init("logfile.txt");

    int choice = 0;
    char filename[MAX_FILENAME_LENGTH];
    char text[1000];
    int shift;

    while (choice != -1) {
        if (scanf("%d", &choice) != 1) {
            printf("n/a\n");
            clear_input_buffer();
            continue;
        }
        clear_input_buffer();

        switch (choice) {
            case 1:
                fgets(filename, MAX_FILENAME_LENGTH, stdin);
                filename[strcspn(filename, "\n")] = 0;
                if (filename[0] != '/') {
                    char src_filename[MAX_FILENAME_LENGTH + strlen(SRC_FOLDER)];
                    strcpy(src_filename, SRC_FOLDER);
                    strcat(src_filename, filename);
                    strcpy(filename, src_filename);
                }
                // Запись лога о чтении файла
                logcat(INFO, "Reading file");
                read_and_print_file(filename);
                break;
            case 2:
                fgets(text, sizeof(text), stdin);
                text[strcspn(text, "\n")] = 0;
                if (strcmp(text, "hi") == 0) {
                    printf("%s\n", text);
                    break;
                }
                if (access(filename, F_OK) != -1) {
                    // Запись лога о добавлении текста в файл
                    logcat(INFO, "Appending text to file");
                    append_to_file(filename, text);
                    read_and_print_file(filename);
                } else {
                    printf("n/a\n");
                }
                break;
            case 3:
                printf("Enter Caesar cipher shift: ");
                scanf("%d", &shift);
                clear_input_buffer();
                printf("Enter directory for .c files encryption: ");
                fgets(filename, MAX_FILENAME_LENGTH, stdin);
                filename[strcspn(filename, "\n")] = 0;
                // Запись лога о шифровании файлов
                logcat(INFO, "Encrypting .c files");
                caesar_cipher_c_files(filename, shift);
                clear_header_files(filename);
                break;
            case 4:
                printf("Enter directory for .c files encryption and .h files cleanup: ");
                fgets(filename, MAX_FILENAME_LENGTH, stdin);
                filename[strcspn(filename, "\n")] = 0;
                // Запись лога о шифровании файлов и очистке .h файлов
                logcat(INFO, "Encrypting .c files and cleaning .h files");

                clear_header_files(filename);
                break;
            case -1:
                break;
            default:
                printf("Некорректный выбор. Попробуйте снова.\n");
                break;
        }
    }

    // Завершение работы логгера
    log_close();

    return 0;
}
