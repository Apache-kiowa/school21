#ifndef LOGGER_H
#define LOGGER_H

typedef enum { DEBUG, INFO, WARNING, ERROR } LogLevel;

#ifdef ENABLE_LOGGER_FUNCTIONS
const char *log_level_str(LogLevel level);
void log_init(const char *filename);
void logcat(LogLevel level, const char *message);
void log_close();
#endif

#endif  // LOGGER_H
