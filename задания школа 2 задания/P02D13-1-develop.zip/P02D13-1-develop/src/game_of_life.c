#include <ncurses.h>
#include <stdio.h>
#include <unistd.h>

#define VISOTA 25
#define SHIRINA 80

void enterMatrix(int matr[VISOTA][SHIRINA]);

void renewalMatr(int matr1[VISOTA][SHIRINA], int matr2[VISOTA][SHIRINA]);

int neighborsCount(int matr1[VISOTA][SHIRINA], int i, int j);

int liveOrDie(int neighbors, int condition);

void drawAgain(int matr2[VISOTA][SHIRINA], int matr1[VISOTA][SHIRINA]);

int staticField(int matr1[VISOTA][SHIRINA], int matr2[VISOTA][SHIRINA]);

int speedControl(char control_button, int *flag, int time_mili_sec);

int liveCellCounter(int matr[VISOTA][SHIRINA]);

int main() {
    int matr1[VISOTA][SHIRINA];
    int matr2[VISOTA][SHIRINA];
    int time_mili_sec = 500;
    int stop = 0;

    enterMatrix(matr1);
    if (freopen("/dev/tty", "r", stdin)) initscr();
    nodelay(stdscr, true);

    while (stop != 1) {
        char control_button = getch();

        if (liveCellCounter(matr1) == 0) {
            stop = 1;
        }

        time_mili_sec = speedControl(control_button, &stop, time_mili_sec);

        usleep(time_mili_sec * 1000);
        clear();
        renewalMatr(matr1, matr2);

        if (staticField(matr1, matr2) == 2000) {
            stop = 1;
        }
        drawAgain(matr2, matr1);
    }

    endwin();
    return 0;
}

void enterMatrix(int matr[VISOTA][SHIRINA]) {
    for (int i = 0; i < VISOTA; i++) {
        for (int j = 0; j < SHIRINA; j++) {
            scanf("%d", &matr[i][j]);
        }
    }
}

void renewalMatr(int matr1[VISOTA][SHIRINA], int matr2[VISOTA][SHIRINA]) {
    for (int i = 0; i < VISOTA; i++) {
        for (int j = 0; j < SHIRINA; j++) {
            matr2[i][j] = liveOrDie(neighborsCount(matr1, i, j), matr1[i][j]);
            if (matr2[i][j] == 1)
                printw("0");
            else
                printw("_");
        }
        printw("\n");
    }
}

int neighborsCount(int matrix[VISOTA][SHIRINA], int row, int col) {
    int sum = 0;

    int rowUp = row - 1, colLeft = col - 1, rowDown = row + 1, colRight = col + 1;

    if (rowUp < 0) rowUp = VISOTA - 1;
    if (colLeft < 0) colLeft = SHIRINA - 1;
    if (rowDown > VISOTA - 1) rowDown = rowDown % VISOTA;
    if (colRight > SHIRINA - 1) colRight = colRight % SHIRINA;

    sum += matrix[rowUp][colLeft];
    sum += matrix[rowUp][col];
    sum += matrix[rowUp][colRight];
    sum += matrix[row][colRight];
    sum += matrix[rowDown][colRight];
    sum += matrix[rowDown][col];
    sum += matrix[rowDown][colLeft];
    sum += matrix[row][colLeft];

    return sum;
}

int liveOrDie(int neighbors, int condition) {
    int next_gen = -1;
    if ((neighbors == 2 || neighbors == 3) && condition == 1) {
        next_gen = 1;
    } else if (neighbors == 3 && condition == 0) {
        next_gen = 1;
    } else {
        next_gen = 0;
    }
    return next_gen;
}

void drawAgain(int matr2[VISOTA][SHIRINA], int matr1[VISOTA][SHIRINA]) {
    for (int i = 0; i < VISOTA; i++) {
        for (int j = 0; j < SHIRINA; j++) {
            matr1[i][j] = matr2[i][j];
        }
    }
}

int staticField(int matr1[VISOTA][SHIRINA], int matr2[VISOTA][SHIRINA]) {
    int ans = 0;
    for (int i = 0; i < VISOTA; i++) {
        for (int j = 0; j < SHIRINA; j++) {
            if (matr1[i][j] == matr2[i][j]) ans++;
        }
    }
    return ans;
}

int speedControl(char control_button, int *flag, int time_mili_sec) {
    if (control_button == '1')
        time_mili_sec = 900;
    else if (control_button == '2')
        time_mili_sec = 400;
    else if (control_button == '3')
        time_mili_sec = 70;
    else if (control_button == 'q')
        *flag = 1;

    return time_mili_sec;
}

int liveCellCounter(int matr[VISOTA][SHIRINA]) {
    int sum = 0;
    for (int i = 0; i < VISOTA; i++) {
        for (int j = 0; j < SHIRINA; j++) {
            sum += matr[i][j];
        }
    }
    return sum;
}
