#include <stdio.h>

void PlayingFieldRacketBall(int LRacketPosition, int RRacketPosition, int currentPositionBall) {
    for (int height = 0; height < 25; height++) {
        for (int width = 0; width < 80; width++) {
            if (height == 0 || height == 24) {
                printf("*");
            } else if (((height == LRacketPosition || height == LRacketPosition + 1 ||
                         height == LRacketPosition - 1) &&
                        width == 0) ||
                       ((height == RRacketPosition || height == RRacketPosition + 1 ||
                         height == RRacketPosition - 1) &&
                        width == 79)) {
                printf("|");
            } else if (height == 12 && width == currentPositionBall) {
                printf("o");
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
}
int leftPlayerMove(char key, int currentPosition) {
    if (key == 'a') {
        if (currentPosition > 2) {
            currentPosition--;
        }
    } else if (key == 'z') {
        if (currentPosition < 22) {
            currentPosition++;
        }
    }
    return currentPosition;
}
int RightPlayerMove(char key, int currentPosition) {
    if (key == 'k') {
        if (currentPosition > 2) {
            currentPosition--;
        }
    } else if (key == 'm') {
        if (currentPosition < 22) {
            currentPosition++;
        }
    }
    return currentPosition;
}

int main() {
    int LRacketPosition = 12;
    int RRacketPosition = 12;
    int currentPositionBall = 1;
    int pastBall;
    int playerOneScore = 0;
    int playerTwoScore = 0;

    while (playerOneScore <= 21 || playerTwoScore <= 21) {
        if (playerOneScore == 21) {
            printf("Player 1 win! Congratulations!");
            break;
        } else if (playerTwoScore == 21) {
            printf("Player 2 win! Congratulations!");
            break;
        }

        char key;
        key = getchar();
        if (key == 'a' || key == 'z') {
            LRacketPosition = leftPlayerMove(key, LRacketPosition);
            if (currentPositionBall == 1 &&
                (LRacketPosition == 11 || LRacketPosition == 12 || LRacketPosition == 13)) {
                pastBall = currentPositionBall;
                currentPositionBall++;
                PlayingFieldRacketBall(LRacketPosition, RRacketPosition, currentPositionBall);
            } else if (currentPositionBall == 78 &&
                       (RRacketPosition == 11 || RRacketPosition == 12 || RRacketPosition == 13)) {
                pastBall = currentPositionBall;
                currentPositionBall--;
                PlayingFieldRacketBall(LRacketPosition, RRacketPosition, currentPositionBall);
            } else if (currentPositionBall == 1 &&
                       (LRacketPosition != 11 && LRacketPosition != 12 && LRacketPosition != 13)) {
                playerTwoScore++;
                printf("Player 1: %d\nPlayer 2: %d\n", playerOneScore, playerTwoScore);
                currentPositionBall = 1;
                pastBall = 0;
                LRacketPosition = 12;
                RRacketPosition = 12;
            } else if (currentPositionBall == 78 &&
                       (RRacketPosition != 11 && RRacketPosition != 12 && RRacketPosition != 13)) {
                playerOneScore++;
                printf("Player 1: %d\nPlayer 2: %d\n", playerOneScore, playerTwoScore);
                currentPositionBall = 78;
                pastBall = 0;
                LRacketPosition = 12;
                RRacketPosition = 12;
            } else if (currentPositionBall > 1 && currentPositionBall < 78) {
                if (pastBall < currentPositionBall) {
                    pastBall = currentPositionBall;
                    currentPositionBall++;
                    PlayingFieldRacketBall(LRacketPosition, RRacketPosition, currentPositionBall);
                } else if (pastBall > currentPositionBall) {
                    pastBall = currentPositionBall;
                    currentPositionBall--;
                    PlayingFieldRacketBall(LRacketPosition, RRacketPosition, currentPositionBall);
                }
            } else {
                printf("Ball motion mistake!\n");
            }
        } else if (key == 'k' || key == 'm') {
            RRacketPosition = RightPlayerMove(key, RRacketPosition);
            {
                if (currentPositionBall == 1 &&
                    (LRacketPosition == 11 || LRacketPosition == 12 || LRacketPosition == 13)) {
                    pastBall = currentPositionBall;
                    currentPositionBall++;
                    PlayingFieldRacketBall(LRacketPosition, RRacketPosition, currentPositionBall);
                } else if (currentPositionBall == 78 &&
                           (RRacketPosition == 11 || RRacketPosition == 12 || RRacketPosition == 13)) {
                    pastBall = currentPositionBall;
                    currentPositionBall--;
                    PlayingFieldRacketBall(LRacketPosition, RRacketPosition, currentPositionBall);
                } else if (currentPositionBall == 1 &&
                           (LRacketPosition != 11 && LRacketPosition != 12 && LRacketPosition != 13)) {
                    playerTwoScore++;
                    printf("Player 1: %d\nPlayer 2: %d\n", playerOneScore, playerTwoScore);
                    currentPositionBall = 1;
                    pastBall = 0;
                    LRacketPosition = 12;
                    RRacketPosition = 12;
                } else if (currentPositionBall == 78 &&
                           (RRacketPosition != 11 && RRacketPosition != 12 && RRacketPosition != 13)) {
                    playerOneScore++;
                    printf("Player 1: %d\nPlayer 2: %d\n", playerOneScore, playerTwoScore);
                    currentPositionBall = 78;
                    pastBall = 0;
                    LRacketPosition = 12;
                    RRacketPosition = 12;
                } else if (currentPositionBall > 1 && currentPositionBall < 78) {
                    if (pastBall < currentPositionBall) {
                        pastBall = currentPositionBall;
                        currentPositionBall++;
                        PlayingFieldRacketBall(LRacketPosition, RRacketPosition, currentPositionBall);
                    } else if (pastBall > currentPositionBall) {
                        pastBall = currentPositionBall;
                        currentPositionBall--;
                        PlayingFieldRacketBall(LRacketPosition, RRacketPosition, currentPositionBall);
                    }
                } else {
                    printf("Ball motion mistake!\n");
                }
            }
        } else if (key == ' ') {
            if (currentPositionBall == 1 &&
                (LRacketPosition == 11 || LRacketPosition == 12 || LRacketPosition == 13)) {
                pastBall = currentPositionBall;
                currentPositionBall++;
                PlayingFieldRacketBall(LRacketPosition, RRacketPosition, currentPositionBall);
            } else if (currentPositionBall == 78 &&
                       (RRacketPosition == 11 || RRacketPosition == 12 || RRacketPosition == 13)) {
                pastBall = currentPositionBall;
                currentPositionBall--;
                PlayingFieldRacketBall(LRacketPosition, RRacketPosition, currentPositionBall);
            } else if (currentPositionBall == 1 &&
                       (LRacketPosition != 11 && LRacketPosition != 12 && LRacketPosition != 13)) {
                playerTwoScore++;
                printf("Player 1: %d\nPlayer 2: %d\n", playerOneScore, playerTwoScore);
                currentPositionBall = 1;
                pastBall = 0;
                LRacketPosition = 12;
                RRacketPosition = 12;
            } else if (currentPositionBall == 78 &&
                       (RRacketPosition != 11 && RRacketPosition != 12 && RRacketPosition != 13)) {
                playerOneScore++;
                printf("Player 1: %d\nPlayer 2: %d\n", playerOneScore, playerTwoScore);
                currentPositionBall = 78;
                pastBall = 0;
                LRacketPosition = 12;
                RRacketPosition = 12;
            } else if (currentPositionBall > 1 && currentPositionBall < 78) {
                if (pastBall < currentPositionBall) {
                    pastBall = currentPositionBall;
                    currentPositionBall++;
                    PlayingFieldRacketBall(LRacketPosition, RRacketPosition, currentPositionBall);
                } else if (pastBall > currentPositionBall) {
                    pastBall = currentPositionBall;
                    currentPositionBall--;
                    PlayingFieldRacketBall(LRacketPosition, RRacketPosition, currentPositionBall);
                }
            } else {
                printf("Ball motion mistake!\n");
            }
        } else if (key == 'q') {
            printf("Player 1: %d\nPlayer 2: %d\n", playerOneScore, playerTwoScore);
            break;
        }
    }
}
