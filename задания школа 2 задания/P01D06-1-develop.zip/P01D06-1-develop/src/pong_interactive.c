#include <ncurses.h>
#include <stdio.h>
#include <unistd.h>

#define STR 25
#define ROW 80

void arena(char field[STR][ROW]);
int racket(char field[STR][ROW], int *PlayerLeft_raket, int *PlayerRight_raket);
void ball(char field[STR][ROW], int PlayerLeft_raket, int PlayerRight_raket, int *ball_i, int *ball_j,
          int *gorizont,
          int *vertical);  // Ball physics
void goal(int *score, int *PlayerLeft_raket, int *PlayerRight_raket, int *ball_i, int *ball_j, int *gorizont,
          int *vertical);  // Update score, field to default
void draw_field(char field[STR][ROW]);

int main() {
    char field[STR][ROW];
    int PlayerLeft_raket = STR / 2, PlayerRight_raket = STR / 2;
    int ball_i = STR / 2, ball_j = ROW / 2;
    int vertical = 1, gorizont = 1;
    int left_score = 0, right_score = 0;
    char winner = 'n';
    char input = 'f';

    initscr();

    do {
        nodelay(stdscr, true);

        arena(field);
        input = racket(field, &PlayerLeft_raket, &PlayerRight_raket);
        ball(field, PlayerLeft_raket, PlayerRight_raket, &ball_i, &ball_j, &gorizont, &vertical);

        if (ball_j == 1)
            goal(&right_score, &PlayerLeft_raket, &PlayerRight_raket, &ball_i, &ball_j, &gorizont, &vertical);
        else if (ball_j == ROW - 2)
            goal(&left_score, &PlayerLeft_raket, &PlayerRight_raket, &ball_i, &ball_j, &gorizont, &vertical);

        clear();
        if (left_score == 21) {
            winner = 'l';
            break;
        } else if (right_score == 21) {
            winner = 'r';
            break;
        }
        usleep(30 * 1000);
        mvprintw(0, 0, " The LEFT PLAYER POINTS = %d\n", left_score);
        mvprintw(0, 76, "The RIGHT PLAYER POINTS = %d\n", right_score);

        draw_field(field);
    } while (input != 'q');

    endwin();

    if (winner == 'l') {
        printf("Hurray! The Left Player Won!");
    } else if (winner == 'r') {
        printf("Hurray! The Right Player Won!");
    }

    return 0;
}

void arena(char field[STR][ROW]) {
    for (int i = 0; i < STR; i++) {
        for (int j = 0; j < ROW; j++) {
            if (i == 0 || i == STR - 1) {
                field[i][j] = '-';
            } else if (j == 0 || j == ROW - 1) {
                field[i][j] = '*';
            } else if (j == ROW / 2) {
                field[i][j] = '.';
            } else {
                field[i][j] = ' ';
            }
        }
    }
}

int racket(char field[STR][ROW], int *PlayerLeft_raket, int *PlayerRight_raket) {
    char input = getch();

    switch (input) {
        case 'a': {
            if ((*PlayerLeft_raket) > 3) (*PlayerLeft_raket)--;
            break;
        }
        case 'z': {
            if ((*PlayerLeft_raket) < STR - 4) (*PlayerLeft_raket)++;
            break;
        }
        case 'k': {
            if ((*PlayerRight_raket) > 3) (*PlayerRight_raket)--;
            break;
        }
        case 'm': {
            if ((*PlayerRight_raket) < STR - 4) (*PlayerRight_raket)++;
            break;
        }
    }

    field[*PlayerLeft_raket + 1][1] = '|';
    field[*PlayerLeft_raket][1] = '|';
    field[*PlayerLeft_raket - 1][1] = '|';

    field[*PlayerRight_raket + 1][ROW - 2] = '|';
    field[*PlayerRight_raket][ROW - 2] = '|';
    field[*PlayerRight_raket - 1][ROW - 2] = '|';

    return input;
}

void ball(char field[STR][ROW], int PlayerLeft_raket, int PlayerRight_raket, int *ball_i, int *ball_j,
          int *gorizont, int *vertical) {
    if ((*ball_i) == 1 && (*gorizont) == 1 && (*vertical) == -1)
        (*vertical) *= -1;
    else if ((*ball_i) == 1 && (*gorizont) == -1 && (*vertical) == -1)
        (*vertical) *= -1;
    else if ((*ball_i) == STR - 2 && (*gorizont) == 1 && (*vertical) == 1)
        (*vertical) *= -1;
    else if ((*ball_i) == STR - 2 && (*gorizont) == -1 && (*vertical) == 1)
        (*vertical) *= -1;
    else if ((*ball_j) == 2 && (*gorizont) == -1 && (*vertical) == 1 &&
             ((*ball_i) == PlayerLeft_raket || (*ball_i) == PlayerLeft_raket + 1 ||
              (*ball_i) == PlayerLeft_raket - 1 || (*ball_i) == PlayerLeft_raket + 2 ||
              (*ball_i) == PlayerLeft_raket - 2))
        (*gorizont) *= -1;
    else if ((*ball_j) == 2 && (*gorizont) == -1 && (*vertical) == -1 &&
             ((*ball_i) == PlayerLeft_raket || (*ball_i) == PlayerLeft_raket + 1 ||
              (*ball_i) == PlayerLeft_raket - 1 || (*ball_i) == PlayerLeft_raket + 2 ||
              (*ball_i) == PlayerLeft_raket - 2))
        (*gorizont) *= -1;
    else if ((*ball_j) == ROW - 3 && (*gorizont) == 1 && (*vertical) == 1 &&
             ((*ball_i) == PlayerRight_raket || (*ball_i) == PlayerRight_raket + 1 ||
              (*ball_i) == PlayerRight_raket - 1 || (*ball_i) == PlayerRight_raket + 2 ||
              (*ball_i) == PlayerRight_raket - 2))
        (*gorizont) *= -1;
    else if ((*ball_j) == ROW - 3 && (*gorizont) == 1 && (*vertical) == -1 &&
             ((*ball_i) == PlayerRight_raket || (*ball_i) == PlayerRight_raket + 1 ||
              (*ball_i) == PlayerRight_raket - 1 || (*ball_i) == PlayerRight_raket + 2 ||
              (*ball_i) == PlayerRight_raket - 2))
        (*gorizont) *= -1;

    (*ball_i) += (*vertical);
    (*ball_j) += (*gorizont);

    field[*ball_i][*ball_j] = 'o';
}

void goal(int *score, int *PlayerLeft_raket, int *PlayerRight_raket, int *ball_i, int *ball_j, int *gorizont,
          int *vertical) {
    (*score)++;

    *PlayerLeft_raket = STR / 2;
    *PlayerRight_raket = STR / 2;

    *ball_i = STR / 2;
    *ball_j = ROW / 2;
    (*gorizont) *= -1;
    (*vertical) *= -1;
}

void draw_field(char field[STR][ROW]) {
    for (int i = 0; i < STR; i++) {
        for (int j = 0; j < ROW; j++) {
            printw("%c", field[i][j]);
        }
        printw("\n");
    }
}
