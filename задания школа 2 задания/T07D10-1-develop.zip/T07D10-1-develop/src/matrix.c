#include <stdio.h>
#include <stdlib.h>

// Макрос для игнорирования неиспользуемых параметров
#define UNUSED_PARAM(x) (void)(x)

// Функция для выделения памяти под матрицу статически
void allocate_static(int n, int m) {
    UNUSED_PARAM(n);
    UNUSED_PARAM(m);
    // Ничего не нужно делать, так как память уже выделена статически
}

// Функция для выделения памяти под матрицу динамически
int **allocate_dynamic(int n, int m) {
    int **matrix = (int **)malloc(n * sizeof(int *));
    if (matrix == NULL) {
        return NULL;  // В случае ошибки выделения памяти возвращаем NULL
    }

    for (int i = 0; i < n; i++) {
        matrix[i] = (int *)malloc(m * sizeof(int));
        if (matrix[i] == NULL) {
            // Ошибка выделения памяти, освобождаем ранее выделенную память и возвращаем NULL
            for (int j = 0; j < i; j++) {
                free(matrix[j]);
            }
            free(matrix);
            return NULL;
        }
    }

    return matrix;
}

// Функция для освобождения памяти под динамическую матрицу
void deallocate_dynamic(int **matrix, int n) {
    for (int i = 0; i < n; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

// Функция для ввода матрицы
void input(int **matrix, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}

// Функция для вывода матрицы
void output(int **matrix, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            printf("%d", matrix[i][j]);
            if (j < m - 1) {
                printf(" ");
            }
        }
        if (i < n - 1) {
            printf("\n");
        }
    }
}

int main() {
    int choice, n, m;
    int **matrix = NULL;

    // Ввод размеров матрицы
    if (scanf("%d %d", &n, &m) != 2) {
        printf("n/a\n");
        return 0;
    }

    // Выбор способа выделения памяти
    if (scanf("%d", &choice) != 1) {
        printf("n/a\n");
        return 0;
    }

    switch (choice) {
        case 1:
            allocate_static(n, m);
            break;
        case 2:
        case 3:
        case 4:
            matrix = allocate_dynamic(n, m);
            if (matrix == NULL) {
                printf("n/a\n");
                return 0;
            }
            break;
        default:
            printf("n/a\n");
            return 0;
    }

    // Ввод матрицы
    input(matrix, n, m);

    // Вывод матрицы
    output(matrix, n, m);

    // Освобождение памяти
    if (choice != 1) {
        deallocate_dynamic(matrix, n);
    }

    return 0;
}
