#include <stdio.h>
#include <stdlib.h>

int func_comp(const void *a, const void *b);

void sort_vertical(int **matrix, int n, int m, int **result_matrix);

void sort_horizontal(int **matrix, int n, int m, int **result_matrix);
void input(int ***matrix, int *n, int *m);
void output(int **matrix, int n, int m);

int main() {
    int **matrix, **result;
    int n, m;

    input(&matrix, &n, &m);

    // Allocate memory for the result matrices
    result = (int **)malloc(n * sizeof(int *));
    for (int i = 0; i < n; i++) {
        result[i] = (int *)malloc(m * sizeof(int));
    }

    // Sort and output vertically
    sort_vertical(matrix, n, m, result);
    output(result, n, m);
    printf("\n");

    // Sort and output horizontally
    sort_horizontal(matrix, n, m, result);
    output(result, n, m);

    // Free allocated memory
    for (int i = 0; i < n; i++) {
        free(matrix[i]);
        free(result[i]);
    }
    free(matrix);
    free(result);

    return 0;
}

int func_comp(const void *a, const void *b) { return (*(int *)a - *(int *)b); }

void sort_vertical(int **matrix, int n, int m, int **result_matrix) {
    // Создаем временный массив для хранения значений всех элементов исходной матрицы
    int temp[n * m];
    int index = 0;

    // Считываем все элементы исходной матрицы во временный массив, обходя ее по столбцам
    for (int j = 0; j < m; j++) {
        if (j % 2 == 0) {
            // Четные столбцы - движение вниз
            for (int i = 0; i < n; i++) {
                temp[index++] = matrix[i][j];
            }
        } else {
            // Нечетные столбцы - движение вверх
            for (int i = n - 1; i >= 0; i--) {
                temp[index++] = matrix[i][j];
            }
        }
    }

    // Сортируем временный массив
    qsort(temp, n * m, sizeof(int), func_comp);

    // Записываем отсортированные значения из временного массива в результирующую матрицу
    index = 0;
    for (int j = 0; j < m; j++) {
        if (j % 2 == 0) {
            // Четные столбцы - движение вниз
            for (int i = 0; i < n; i++) {
                result_matrix[i][j] = temp[index++];
            }
        } else {
            // Нечетные столбцы - движение вверх
            for (int i = n - 1; i >= 0; i--) {
                result_matrix[i][j] = temp[index++];
            }
        }
    }
}

void sort_horizontal(int **matrix, int n, int m, int **result_matrix) {
    // Создаем временный массив для хранения значений всех элементов исходной матрицы
    int temp[n * m];
    int index = 0;

    // Считываем все элементы исходной матрицы во временный массив, обходя ее по строкам
    for (int i = 0; i < n; i++) {
        if (i % 2 == 0) {
            // Четные строки - движение вправо
            for (int j = 0; j < m; j++) {
                temp[index++] = matrix[i][j];
            }
        } else {
            // Нечетные строки - движение влево
            for (int j = m - 1; j >= 0; j--) {
                temp[index++] = matrix[i][j];
            }
        }
    }

    // Сортируем временный массив
    qsort(temp, n * m, sizeof(int), func_comp);

    // Записываем отсортированные значения из временного массива в результирующую матрицу
    index = 0;
    for (int i = 0; i < n; i++) {
        if (i % 2 == 0) {
            // Четные строки - движение вправо
            for (int j = 0; j < m; j++) {
                result_matrix[i][j] = temp[index++];
            }
        } else {
            // Нечетные строки - движение влево
            for (int j = m - 1; j >= 0; j--) {
                result_matrix[i][j] = temp[index++];
            }
        }
    }
}

void input(int ***matrix, int *n, int *m) {
    scanf("%d %d", n, m);

    // Проверяем, если n и m равны 0, выводим "n/a"
    if (*n == 0 && *m == 0) {
        printf("n/a\n");
        exit(EXIT_SUCCESS);  // Выходим из программы успешно, так как "n/a" было выведено успешно.
    }

    // Выделяем память под массив указателей на строки
    *matrix = (int **)malloc(*n * sizeof(int *));
    if (*matrix == NULL) {
        printf("Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }

    // Выделяем память под каждую строку
    for (int i = 0; i < *n; i++) {
        (*matrix)[i] = (int *)malloc(*m * sizeof(int));
        if ((*matrix)[i] == NULL) {
            printf("Memory allocation failed.\n");
            exit(EXIT_FAILURE);
        }
    }

    // Вводим элементы матрицы
    for (int i = 0; i < *n; i++) {
        for (int j = 0; j < *m; j++) {
            scanf("%d", &(*matrix)[i][j]);
        }
    }
}

void output(int **matrix, int n, int m) {
    // Выводим элементы матрицы
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            printf("%d", matrix[i][j]);
            if (j < m - 1) {
                printf(" ");
            }
        }
        printf("\n");
    }
}
